jQuery(document).ready(function($) { 

	var owl = $("#owl-2");
	
		owl.owlCarousel({
		items: 6,
		margin:20,
		nav: true,
		navText: ["<i class='fa fa-chevron-left icon_preview'></i>","<i class='fa fa-chevron-right icon_preview'></i>"],
		responsive: {
			0 : {
			    items: 1
			},
			540: {
			    items: 2
			},
			992: {
			    items: 6
			}
		}
	});
		
});